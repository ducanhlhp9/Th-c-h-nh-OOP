# MISP-assembly-of-HEDSPI
Bài tập lớn MIPS của HEDSPI

Có 1 số bug trong bài 2 về vòng lặp vô hạn dẫn đến treo MIPS

Làm ít chức năng để thầy hỏi thì bổ sung thêm vào
